print('Hello, world')

print("Python has three numeric types: int, float, and complex")
myValue=1
print(myValue)
print(type(myValue))
print(str(myValue) + "is of the data type " + str(type(myValue)))
myValue=True
print(myValue)
print(str(myValue) + " is of the data type " + str(type(myValue)))
myValue=False
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))


myString="This is a string"
print (myString)
print(type(myString))

print(myString + " is of the data type" + str (type(myString)))

firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name=input("what is your name?")

print(name)

color=input("what is your favorite color?")
animal=input ("What is your favorite animal?  ")



userReply=input("Do you need to ship this package? (enter yes or no)" )
if userReply== "yes"
print("we can help you ship that package!")

